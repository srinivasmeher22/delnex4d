package com.mycompany.fds.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mycompany.fds.model.Restaurant;
import com.mycompany.fds.model.items;

@Transactional
@Component
public class RestaurantDao {
	@Autowired
	SessionFactory sessionFactory;

	
	public RestaurantDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	public RestaurantDao()
	{
		
	}
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	//saving new data
//	public void saveRestaurant(Restaurant rest) {
//		Session session=  sessionFactory.getCurrentSession();
//		session.save(rest);
//	}
	
	//display all data
	public ArrayList<Restaurant> getRestaurants()
	{
	Session session=  sessionFactory.getCurrentSession();
	return (ArrayList<Restaurant>) session.createQuery("from Restaurant").list();

	}
	
	//searching by location
	public ArrayList<Restaurant> searchByAddr(String address) {
		ArrayList<Restaurant> blackList = new ArrayList<Restaurant>();
		Session session = sessionFactory.getCurrentSession();
		Criteria crit = session.createCriteria(Restaurant.class);
		crit.add(Restrictions.like("address",address,MatchMode.START).ignoreCase());
		
		blackList = (ArrayList<Restaurant>)crit.list();
		return blackList;
		
	}
	
	//search by name
	public Restaurant searchByName(String name) {
		Session session = sessionFactory.getCurrentSession();
		Criteria crit = session.createCriteria(Restaurant.class);
		crit.add(Restrictions.eq("name",name));
		
		try{
			Restaurant rest =(Restaurant) crit.uniqueResult();
			return rest;
		}
		catch(Exception e) {
			return null;
		}
	}
	
	//search by id
		public ArrayList<items> getRestById(int id) {
			ArrayList<items> rs=new ArrayList<items>();
			Session session = sessionFactory.getCurrentSession();
			Criteria crit = session.createCriteria(items.class);
			crit.add(Restrictions.eq("id",id));
			
			try{
				rs = (ArrayList<items>)crit.list();;
				return rs;
				
			}
			catch(Exception e) {
				return null;
			}
		}
	
//	public void removeData(Restaurant rest) {
//		Session session = sessionFactory.getCurrentSession();
//		session.delete(rest);
//	}
//	public void updateData(Restaurant newRest) {
//		Session session = sessionFactory.getCurrentSession();
//		session.update(newRest);
//	}
}
