package com.mycompany.fds;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.mycompany.fds.dao.CustomerDao;
import com.mycompany.fds.model.Customer;

@Controller
public class HomeController {
	
	
	@Autowired
	CustomerDao customerdao;

	@RequestMapping("/")
	public String home() {
		
		return "redirect";
	}
	
	
	@RequestMapping("saveCustomer")
	public String saveCustomer(@ModelAttribute Customer customer)
	{
		
	customerdao.saveCustomer(customer);
		
		return "redirect2";
	}
	
	
	@RequestMapping("login")
	public String loginCustomer()
	{
		
	//customerdao.saveCustomer(customer);
		
		return "redirect2";
	}
}