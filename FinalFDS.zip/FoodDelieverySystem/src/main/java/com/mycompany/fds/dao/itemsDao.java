package com.mycompany.fds.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mycompany.fds.model.Restaurant;
import com.mycompany.fds.model.items;

@Transactional
@Component
public class itemsDao {
	@Autowired
	SessionFactory sessionFactory;

	
	public itemsDao(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	
	public itemsDao()
	{
		
	}
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	//display all data from bawarchi
		public ArrayList<items> getitemsbawarchi()
		{
		Session session=  sessionFactory.getCurrentSession();
		return (ArrayList<items>) session.createSQLQuery("select * from items where id=1").list();

		}
		//display all data from paradise
		public ArrayList<items> getitemsparadise()
		{
		Session session=  sessionFactory.getCurrentSession();
		return (ArrayList<items>) session.createSQLQuery("select * from items where id=2").list();

		}
		//display all data from ajeebo
		public ArrayList<items> getitemsajeebo()
		{
		Session session=  sessionFactory.getCurrentSession();
		return (ArrayList<items>) session.createSQLQuery("seelect * from items where id=3").list();

		}
		
		
		
		
		
}






