package com.mycompany.fds.dao;

import javax.transaction.Transactional;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mycompany.fds.model.Customer;

@Transactional
@Component
public class LoginDao {

@Autowired
SessionFactory sessionFactory;




public LoginDao(SessionFactory sessionFactory) {
super();
this.sessionFactory = sessionFactory;
}

public LoginDao()
{

}
public SessionFactory getSessionFactory() {
return sessionFactory;
}

public void setSessionFactory(SessionFactory sessionFactory) {
this.sessionFactory = sessionFactory;
}

public boolean validateUser(String umail, String upassword) {
Session session =  sessionFactory.getCurrentSession();
  Query query = session.createQuery("from Customer c where c.email =:email and password = :password");

  query.setParameter("email", umail);
  query.setParameter("password", upassword);
 
  Customer customer = (Customer)query.uniqueResult();
  if (customer != null) {
  return true;
  }
 
  return false;
 
  //session
// Criteria crit = session.createCriteria(Customer.class);
// Criterion cr1 = Restrictions.ilike("email",umail);
// Criterion cr2 = Restrictions.like("password",upassword);
// LogicalExpression login = Restrictions.and(cr1, cr2);
// crit.add(login);
// Customer cust = (Customer) crit.list();
// return cust;
}
}
