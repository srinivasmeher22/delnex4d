package com.mycompany.fds;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.mycompany.fds.dao.LoginDao;


@Controller
public class LoginController {

@Autowired
LoginDao logindao;




@RequestMapping("validateUser")
public String validateUser(@RequestParam() String Email, String Password)
{
System.out.println("hello");
boolean res =  logindao.validateUser(Email, Password);

if (res==true) {
System.out.println("Done");
return "home";
}
else {
System.out.println("Notdone");
return "redirect2";
}



}
}
