package com.mycompany.fds;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mycompany.fds.dao.RestaurantDao;
import com.mycompany.fds.dao.itemsDao;
import com.mycompany.fds.model.items;

@Controller
public class itemController {
	@Autowired
	itemsDao items;
	
	
	@RequestMapping("getAllitemsbawarchi")
	public String getAllitemsbawarchi(Model model) {
		ArrayList<items> restList = items.getitemsbawarchi();
		model.addAttribute("restList",restList);
		for(items rest:restList) {
			System.out.println(rest);
		}
		if(restList == null) {
			System.out.println("so it was reallly empty");
		}
		return "hotel1";
	}
	@RequestMapping("getAllitemsparadise")
	public String getAllitemsparadise(Model model) {
		ArrayList<items> restList = items.getitemsparadise();
		model.addAttribute("restList",restList);
		for(items rest:restList) {
			System.out.println(rest);
		}
		if(restList == null) {
			System.out.println("so it was reallly empty");
		}
		return "hotel2";
	}
	@RequestMapping("getAllitemsajeebo")
	public String getAllitemsajeebo(Model model) {
		ArrayList<items> restList = items.getitemsajeebo();
		model.addAttribute("restList",restList);
		for(items rest:restList) {
			System.out.println(rest);
		}
		if(restList == null) {
			System.out.println("so it was reallly empty");
		}
		return "hotel3";
	}
}