package com.mycompany.fds.dao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mycompany.fds.model.Customer;

@Transactional
@Component
public class CustomerDao {

@Autowired
SessionFactory sessionFactory;


public CustomerDao(SessionFactory sessionFactory) {
	super();
	this.sessionFactory = sessionFactory;
}

public CustomerDao()
{
	
}


public SessionFactory getSessionFactory() {
	return sessionFactory;
}

public void setSessionFactory(SessionFactory sessionFactory) {
	this.sessionFactory = sessionFactory;
}

@Transactional
public void saveCustomer(Customer cust)
{
	Session session=  sessionFactory.getCurrentSession();
	session.save(cust);
}
}