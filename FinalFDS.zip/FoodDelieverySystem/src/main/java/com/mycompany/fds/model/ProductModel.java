package com.mycompany.fds.model;

import java.util.ArrayList;
import java.util.List;


import com.mycompany.fds.entities.Product;


public class ProductModel {

	private List<Product> products;

	public ProductModel() {
		this.products = new ArrayList<Product>();
		this.products.add(new Product("p01", "Veg Pulao", "../images/pulao.jpg", 100));
		this.products.add(new Product("p02", "Veg Biriyani", "../images/veg biriyani.jpg", 100));
		this.products.add(new Product("p03", "Chicken Biriyani", "../images/chicken biriyani.jpg", 200));
		this.products.add(new Product("p04", "Mutton Biriyani", "../images/mutton biriyani.jpg", 300));
		this.products.add(new Product("p05", "Ice cream", "../images/ice cream.jpg", 50));
	}

	public List<Product> findAll() {
		return this.products;
	}

	public Product find(String id) {
		for (Product product : this.products) {
			if (product.getId().equalsIgnoreCase(id)) {
				return product;
			}
		}
		return null;
	}

}
