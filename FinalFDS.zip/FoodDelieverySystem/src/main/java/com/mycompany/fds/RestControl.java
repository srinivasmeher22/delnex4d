package com.mycompany.fds;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.fds.dao.RestaurantDao;
import com.mycompany.fds.model.Restaurant;
import com.mycompany.fds.model.items;

@Controller
public class RestControl {
	@Autowired
	RestaurantDao restaurantDao;
	
//	@RequestMapping("/")
//	public String home() {
//		
//		return "home";
//	}
	
	
	
//	@RequestMapping("saveRestaurant")
//	public String saveRestaurant(@ModelAttribute Restaurant rest) {
//		
//		restaurantDao.saveRestaurant(rest);
//		return "home";
//	}
//	
	@RequestMapping("getAllRestaurant")
	public String getAllRestaurant(Model model) {
		ArrayList<Restaurant> restList = restaurantDao.getRestaurants();
		model.addAttribute("restList",restList);
		for(Restaurant rest:restList) {
			System.out.println(rest);
		}
		if(restList == null) {
			System.out.println("so it was reallly empty");
		}
		return "display";
	}
	
	@RequestMapping("advancedSearch")
	public String advancedSearch() {
		return "advanced";
	}
	
	@RequestMapping("getbyName")
	public String getByName(@RequestParam()String name,Model model) {
		
		
		Restaurant restData= restaurantDao.searchByName(name);
		ArrayList<Restaurant> restList = new ArrayList<Restaurant>();
		restList.add(restData);
		model.addAttribute("restList",restList);
		for(Restaurant rest:restList) {
			System.out.println(rest);
		}
		return "display";
	}
	
	@RequestMapping("getbyAddress")
	public String getByAddr(@RequestParam()String address,Model model) {
		ArrayList<Restaurant> restList = restaurantDao.searchByAddr(address);
		model.addAttribute("restList",restList);
		for(Restaurant rest:restList) {
			System.out.println(rest);
		}
		return "display";
	}
	
	
	
	@RequestMapping("getAllitems")
	public String getByRestId(@RequestParam("id") int id,Model model) {
		ArrayList<items> restList1 = restaurantDao.getRestById(id);
		
		model.addAttribute("restList1",restList1);
		for(items rest:restList1) {
			System.out.println(rest);
		}
		return "hotel1";
	}
	
	@RequestMapping("product")
	public String gotochart() {
		return "product/index";
	}
	
	
	
	
//	@RequestMapping("deleteById")
//	public String deleteById(@RequestParam("delId") String id) {
//		int data = Integer.parseInt(id);
//		Restaurant restData= restaurantDao.searchById(data);
//		if(restData != null) {
//			restaurantDao.removeData(restData);
//			System.out.println("Restaraunt data with ID:"+data+" deleted.");
//		}
//		else
//			System.out.println("No such data");
//		return "home";
//	}
	
//	@RequestMapping("updateData")
//	public String updateData(Model model,@RequestParam("upId") String id) {
//		int data = Integer.parseInt(id);
//		Restaurant restData= restaurantDao.searchById(data);
//		if(restData == null) {
//			restData.setId(data);
//		}
//		model.addAttribute("rest",restData);
//		return "updateEntry";
//	}
//	@RequestMapping("entryNewDatas")
//	public String updateThemActually(@ModelAttribute Restaurant rest) {
//		restaurantDao.updateData(rest);	
//		return "home";
//	}
//	
	@RequestMapping("order-bawarchi")
	public String order1() {
		return "hotel1";
	}
	@RequestMapping("order-paradise")
	public String order2() {
		return "hotel2";
	}
	@RequestMapping("order-ajeebo")
	public String order3() {
		return "hotel3";
	}
}
